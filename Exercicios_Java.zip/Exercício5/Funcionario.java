class Pessoa {
    String nome;
    int idade;
    String email;
}

public class Funcionario extends Pessoa {
    double salario;
    String cargo;
    String departamento;
    boolean aprendiz;

    public static void main(String[] args) {
        Funcionario f = new Funcionario();
        f.idade = 15;

        if (f.idade <= 16) {
            f.aprendiz = true;
        } else {
            f.aprendiz = false;
        }

        System.out.println("Aprendiz: " + f.aprendiz);
    }
}
