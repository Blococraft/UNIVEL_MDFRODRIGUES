public class Casa {
    String endereco;
    double preco;
    String tipo;
    double area;

    public Casa() {}

    public Casa(String endereco, double preco, String tipo, double area) {
        this.endereco = endereco;
        this.preco = preco;
        this.tipo = tipo;
        this.area = area;
    }

    public static void main(String[] args) {
        Casa casa1 = new Casa();
        Casa casa2 = new Casa("Rua A, 123", 250000.0, "Sobrado", 100.0);
        System.out.println("Casas instanciadas com sucesso.");
    }
}
