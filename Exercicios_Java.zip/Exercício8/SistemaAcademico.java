import java.util.Scanner;

public class SistemaAcademico {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("1 - Cadastrar Aluno\n2 - Cadastrar Professor\n3 - Sair");
        int opcao = sc.nextInt();

        switch (opcao) {
            case 1:
                System.out.print("Idade do aluno: ");
                int idade = sc.nextInt();
                if (idade >= 16 && idade <= 99) {
                    System.out.print("Renda familiar: ");
                    double renda = sc.nextDouble();
                    System.out.print("Participa de projeto de extensão? (true/false): ");
                    boolean extensao = sc.nextBoolean();

                    if (renda < 1500.00 || extensao) {
                        System.out.println("Aluno cadastrado com direito a auxílio!");
                    } else {
                        System.out.println("Aluno cadastrado sem auxílio.");
                    }
                } else {
                    System.out.println("Idade inválida para ensino superior.");
                }
                break;

            case 2:
                System.out.print("Anos de experiência: ");
                int anosExp = sc.nextInt();
                System.out.print("Possui pós-graduação? (true/false): ");
                boolean pos = sc.nextBoolean();
                System.out.print("É bacharel? (true/false): ");
                boolean bacharel = sc.nextBoolean();

                if (anosExp > 2 && (pos || bacharel)) {
                    System.out.println("Professor classificado como: Efetivo");
                } else {
                    System.out.println("Professor classificado como: Temporário");
                }
                break;

            case 3:
                System.out.println("Saindo...");
                break;

            default:
                System.out.println("Opção inválida.");
        }
        sc.close();
    }
}
