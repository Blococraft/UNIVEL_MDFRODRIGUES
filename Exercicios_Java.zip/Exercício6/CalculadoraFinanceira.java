public class CalculadoraFinanceira {
    public void calcularDesconto(double valorTotal, double percentualDesconto) {
        double valorFinal = valorTotal - (valorTotal * (percentualDesconto / 100));
        System.out.println("Valor final com desconto: R$ " + valorFinal);
    }

    public void calcularDesconto(double valorTotal, double percentualDesconto, int parcelas) {
        double valorFinal = valorTotal - (valorTotal * (percentualDesconto / 100));
        double valorParcela = valorFinal / parcelas;
        System.out.println("Valor final: R$ " + valorFinal + " | " + parcelas + "x de R$ " + valorParcela);
    }

    public static void main(String[] args) {
        CalculadoraFinanceira calc = new CalculadoraFinanceira();
        calc.calcularDesconto(1000.0, 10.0);
        calc.calcularDesconto(1000.0, 10.0, 5);
    }
}
