abstract class FormaGeometrica {
    public abstract double calcularArea();
    public abstract double calcularPerimetro();
}

class Quadrado extends FormaGeometrica {
    double lado;
    public Quadrado(double lado) { this.lado = lado; }
    @Override public double calcularArea() { return lado * lado; }
    @Override public double calcularPerimetro() { return 4 * lado; }
}

class TrianguloEquilatero extends FormaGeometrica {
    double lado;
    public TrianguloEquilatero(double lado) { this.lado = lado; }
    @Override public double calcularArea() { return (Math.sqrt(3) / 4) * (lado * lado); }
    @Override public double calcularPerimetro() { return 3 * lado; }
}

class Circulo extends FormaGeometrica {
    double raio;
    public Circulo(double raio) { this.raio = raio; }
    @Override public double calcularArea() { return Math.PI * raio * raio; }
    @Override public double calcularPerimetro() { return 2 * Math.PI * raio; }
}

public class FormasGeometricas {
    public static void main(String[] args) {
        FormaGeometrica q = new Quadrado(4);
        System.out.println("Área do quadrado: " + q.calcularArea());
    }
}
