public class Tabuada {
    public void calcularTabuada(int numero) {
        for (int i = 1; i <= 10; i++) {
            System.out.println(numero + " x " + i + " = " + (numero * i));
        }
    }

    public static void main(String[] args) {
        Tabuada t = new Tabuada();
        t.calcularTabuada(7);
    }
}
